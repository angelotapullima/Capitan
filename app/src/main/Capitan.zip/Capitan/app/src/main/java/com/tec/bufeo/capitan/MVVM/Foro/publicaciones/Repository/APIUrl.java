package com.tec.bufeo.capitan.MVVM.Foro.publicaciones.Repository;

public class APIUrl {
    public static final String BASE_URL = "https://www.guabba.com/capitan/";
}
